package fr.solmey.clienthings.config;

public class Eggs {
    public Boolean enabled = true;
    public Servers servers = new Servers();
    public Integer maxTime = 5000;
    public Integer maxDistance = 32;
}
